package service;

import exception.BookUnavailableException;
import exception.BorrowLimitExceededException;
import exception.InvalidInputException;
import exception.ItemNotFoundException;
import exception.MemberBlockedException;
import exception.ReturnNotAllowedException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import model.Author;
import model.Book;
import model.FacultyMember;
import model.Fine;
import model.Loan;
import model.LoanItem;
import model.Magazine;
import model.Member;
import model.ReferenceBook;
import util.DateUtil;
import util.InputHelper;

/**
 * Core service class. It aggregates authors, books, members and loans and
 * enforces every business rule of the Library Management System.
 */
public class LibraryService {
    private final String name;
    private final Map<String, Author> authors = new LinkedHashMap<>(); // key = lower-case name
    private final Map<String, Book> books = new LinkedHashMap<>();
    private final Map<String, Member> members = new LinkedHashMap<>();
    private final Map<String, Loan> loans = new LinkedHashMap<>();
    private final Map<String, String> emails = new LinkedHashMap<>(); // e-mail -> member ID
    private int authorSeq = 1;
    private int bookSeq = 1;
    private int memberSeq = 1;
    private int loanSeq = 1;
    private int fineSeq = 1;

    public LibraryService(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /** type: 1 = Book, 2 = Magazine, 3 = Reference book. */
    public Book addBook(String title, String authorName, String subject, int type, int copies, double price)
            throws InvalidInputException {
        if (type < 1 || type > 3) {
            throw new InvalidInputException("Book type must be 1 (Book), 2 (Magazine) or 3 (Reference).");
        }
        if (copies < 1 || copies > 50) {
            throw new InvalidInputException("A title needs 1-50 copies.");
        }
        if (price <= 0) {
            throw new InvalidInputException("Book price must be greater than zero.");
        }

        for (Book b : books.values()) {
            if (b.getTitle().equalsIgnoreCase(title)
                    && b.getAuthor().getName().equalsIgnoreCase(authorName)) {
                throw new InvalidInputException("'" + title + "' by " + authorName
                        + " is already in the catalogue (" + b.getBookId() + ").");
            }
        }

        Author author = authors.get(authorName.toLowerCase());
        if (author == null) {
            author = new Author(String.format("A%03d", authorSeq++), authorName);
            authors.put(authorName.toLowerCase(), author);
        }

        String id = String.format("B%03d", bookSeq++);
        Book book;
        if (type == 2) {
            book = new Magazine(id, title, author, subject, price, copies);
        } else if (type == 3) {
            book = new ReferenceBook(id, title, author, subject, price, copies);
        } else {
            book = new Book(id, title, author, subject, price, copies);
        }

        books.put(id, book);
        return book;
    }

    public Member registerMember(String memberName, String email, boolean faculty) throws InvalidInputException {
        if (emails.containsKey(email.toLowerCase())) {
            throw new InvalidInputException("The e-mail " + email + " is already registered to member "
                    + emails.get(email.toLowerCase()) + ".");
        }

        String id = String.format("M%03d", memberSeq++);
        Member m = faculty
                ? new FacultyMember(id, memberName, email)
                : new Member(id, memberName, email);
        members.put(id, m);
        emails.put(email.toLowerCase(), id);
        return m;
    }

    public Book findBook(String id) throws ItemNotFoundException {
        Book b = books.get(id.toUpperCase());
        if (b == null) {
            throw new ItemNotFoundException("No book found with ID '" + id + "'.");
        }
        return b;
    }

    public Member findMember(String id) throws ItemNotFoundException {
        Member m = members.get(id.toUpperCase());
        if (m == null) {
            throw new ItemNotFoundException("No member found with ID '" + id + "'.");
        }
        return m;
    }

    public Loan findLoan(String id) throws ItemNotFoundException {
        Loan l = loans.get(id.toUpperCase());
        if (l == null) {
            throw new ItemNotFoundException("No loan found with ID '" + id + "'.");
        }
        return l;
    }

    public Loan issueBooks(String memberId, List<String> bookIds, LocalDate date)
            throws ItemNotFoundException, BookUnavailableException, BorrowLimitExceededException,
            MemberBlockedException, InvalidInputException {
        Member member = findMember(memberId);
        if (bookIds.isEmpty()) {
            throw new InvalidInputException("Select at least one book.");
        }
        if (member.hasOverdue(date)) {
            throw new MemberBlockedException(member.getName()
                    + " has overdue books; return them before borrowing more.");
        }
        if (member.getActiveCount() + bookIds.size() > member.getMaxBooks()) {
            throw new BorrowLimitExceededException(member.getName() + " (" + member.getMembershipType()
                    + ") can hold at most " + member.getMaxBooks() + " books at a time ("
                    + member.getActiveCount() + " already on loan).");
        }

        // Validate every book first, so a failed request never issues half of the books.
        List<Book> chosen = new ArrayList<>();
        for (String bid : bookIds) {
            Book book = findBook(bid);
            if (!book.isIssuable()) {
                throw new BookUnavailableException("'" + book.getTitle()
                        + "' is a reference book (library use only).");
            }
            if (!book.isAvailable()) {
                throw new BookUnavailableException("No copy of '" + book.getTitle() + "' (" + bid
                        + ") is currently available.");
            }
            if (member.holds(book)) {
                throw new InvalidInputException(member.getName() + " already holds a copy of '"
                        + book.getTitle() + "'.");
            }
            chosen.add(book);
        }

        for (Book b : chosen) {
            b.issueCopy(); // Second line of defence against issuing a copy that is not on the shelf.
        }

        String id = String.format("LN%03d", loanSeq++);
        Loan loan = new Loan(id, member, chosen, date);
        for (LoanItem item : loan.getItems()) {
            member.addActive(item);
        }
        loans.put(id, loan);
        return loan;
    }

    /** Returns the given books of a loan (or every book when the list is [ALL]) and calculates the fines. */
    public List<Fine> returnBooks(String loanId, List<String> bookIds, LocalDate date)
            throws ItemNotFoundException, ReturnNotAllowedException, InvalidInputException {
        Loan loan = findLoan(loanId);
        if (date.isBefore(loan.getIssueDate())) {
            throw new InvalidInputException("Return date cannot be before the issue date ("
                    + DateUtil.format(loan.getIssueDate()) + ").");
        }

        List<LoanItem> targets = new ArrayList<>();
        if (bookIds.size() == 1 && bookIds.get(0).equals(InputHelper.ALL)) {
            for (LoanItem i : loan.getItems()) {
                if (!i.isReturned()) {
                    targets.add(i);
                }
            }
        } else {
            for (String bid : bookIds) {
                LoanItem item = loan.findItem(bid);
                if (item == null) {
                    throw new ItemNotFoundException("Book " + bid + " is not part of loan "
                            + loan.getLoanId() + ".");
                }
                if (item.isReturned()) {
                    throw new ReturnNotAllowedException("Book " + bid + " of loan " + loan.getLoanId()
                            + " was already returned on " + DateUtil.format(item.getReturnDate()) + ".");
                }
                targets.add(item);
            }
        }

        if (targets.isEmpty()) {
            throw new ReturnNotAllowedException("Every book of loan " + loan.getLoanId() + " is already returned.");
        }

        List<Fine> result = new ArrayList<>();
        for (LoanItem item : targets) {
            Book book = item.getBook();
            long late = item.daysLate(date);
            double policyFine = FinePolicy.grossFine(late, book.getFinePerDay(), book.getPrice());
            Fine fine = new Fine(String.format("FN%03d", fineSeq++), item, date, late, policyFine);
            item.markReturned(date, fine);
            book.returnCopy();
            loan.getMember().removeActive(item);
            result.add(fine);
        }
        return result;
    }

    public String membersTable() {
        StringBuilder sb = new StringBuilder();
        for (Member m : members.values()) {
            sb.append(" ").append(m).append('\n');
        }
        return sb.toString();
    }

    public String booksTable() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-26s %-18s %-10s %-7s %s%n",
                "ID", "Title", "Author", "Type", "Avail", "Price"));
        sb.append("-".repeat(84)).append('\n');
        if (books.isEmpty()) {
            sb.append("(no books added yet)\n");
        }
        for (Book b : books.values()) {
            sb.append(b).append('\n');
            if (b.isIssuable()) {
                sb.append(String.format("\tSubject: %s | Loan %d day(s) | Fine %s/day%n",
                        b.getSubject(), b.getLoanDays(), DateUtil.money(b.getFinePerDay())));
            } else {
                sb.append(String.format("\tSubject: %s | Library use only (cannot be issued)%n", b.getSubject()));
            }
        }
        return sb.toString();
    }

    public String activeLoansTable() {
        StringBuilder sb = new StringBuilder();
        for (Loan l : loans.values()) {
            if (!l.isClosed()) {
                sb.append(String.format(" %-6s %-16s %s%n",
                        l.getLoanId(), DateUtil.fit(l.getMember().getName(), 16), l.bookList()));
            }
        }
        return sb.toString();
    }

    /** Copies of issuable titles that are on the shelf right now. */
    public int issuableAvailable() {
        int n = 0;
        for (Book b : books.values()) {
            if (b.isIssuable()) {
                n += b.getAvailableCopies();
            }
        }
        return n;
    }

    public int issuableTotal() {
        int n = 0;
        for (Book b : books.values()) {
            if (b.isIssuable()) {
                n += b.getTotalCopies();
            }
        }
        return n;
    }

    public boolean hasBooks() {
        return !books.isEmpty();
    }

    public boolean hasMembers() {
        return !members.isEmpty();
    }

    public boolean hasActiveLoans() {
        return !activeLoansTable().isEmpty();
    }
}
