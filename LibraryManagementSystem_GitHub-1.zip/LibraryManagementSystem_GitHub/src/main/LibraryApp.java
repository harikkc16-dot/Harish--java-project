package main;

import exception.InvalidInputException;
import exception.LibraryException;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import model.Book;
import model.Fine;
import model.Loan;
import model.Member;
import service.LibraryService;
import util.DateUtil;
import util.InputHelper;

/** Entry point: menu-driven console interface for the Library Management System. */
public class LibraryApp {

    private static void printMenu() {
        System.out.println();
        System.out.println("*********** LIBRARY MANAGEMENT SYSTEM ***********");
        System.out.println(" 1. Add Book");
        System.out.println(" 2. Register Member");
        System.out.println(" 3. Issue Book");
        System.out.println(" 4. Return Book");
        System.out.println(" 5. Display Books & Availability");
        System.out.println(" 6. Exit");
        System.out.println("*************************************************");
    }

    public static void main(String[] args) {
        LibraryService service = new LibraryService("Central Library");
        Scanner scanner = new Scanner(System.in);
        InputHelper in = new InputHelper(scanner);

        System.out.println("Welcome to " + service.getName());
        boolean running = true;

        while (running) {
            printMenu();
            try {
                int choice = in.readInt("Enter your choice (1-6): ", 1, 6);
                switch (choice) {
                    case 1:
                        addBook(service, in);
                        break;
                    case 2:
                        registerMember(service, in);
                        break;
                    case 3:
                        issueBook(service, in);
                        break;
                    case 4:
                        returnBook(service, in);
                        break;
                    case 5:
                        displayBooks(service);
                        break;
                    case 6:
                        System.out.println("Thank you for using the Library Management System. Goodbye!");
                        running = false;
                        break;
                    default:
                        break;
                }
            } catch (LibraryException e) {
                System.out.println("[ERROR] " + e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println("\nInput ended. Exiting.");
                running = false;
            } catch (RuntimeException e) {
                System.out.println("[UNEXPECTED ERROR] " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static void addBook(LibraryService svc, InputHelper in) throws LibraryException {
        System.out.println("--- Add Book ---");
        String title = in.readText("Book title       : ");
        String author = in.readName("Author name      : ");
        String subject = in.readText("Subject          : ");
        int type = in.readInt("Type (1=Book, 2=Magazine, 3=Reference): ", 1, 3);
        int copies = in.readInt("Number of copies (1-50): ", 1, 50);
        double price = in.readPrice("Book price (Rs.) : ", 1, 100000);

        Book b = svc.addBook(title, author, subject, type, copies, price);
        System.out.println("[OK] Book added -> " + b.getBookId() + " | " + b.getTitle() + " | "
                + b.getBookType() + " | " + b.getTotalCopies()
                + (b.getTotalCopies() == 1 ? " copy" : " copies") + " | " + DateUtil.money(b.getPrice()));
    }

    private static void registerMember(LibraryService svc, InputHelper in) throws LibraryException {
        System.out.println("--- Register Member ---");
        String name = in.readName("Member name : ");
        String email = in.readEmail("Member e-mail: ");
        int type = in.readInt("Type (1=Student, 2=Faculty): ", 1, 2);

        Member m = svc.registerMember(name, email, type == 2);
        System.out.println("[OK] Member registered -> " + m.getMemberId() + " | " + m.getName() + " | "
                + m.getMembershipType() + " | max " + m.getMaxBooks() + " books");
    }

    private static void issueBook(LibraryService svc, InputHelper in) throws LibraryException {
        System.out.println("--- Issue Book ---");
        if (!svc.hasBooks() || !svc.hasMembers()) {
            System.out.println("[INFO] Add a book and register a member first.");
            return;
        }

        System.out.println("Registered members:");
        System.out.print(svc.membersTable());
        String mid = in.readText("Member ID : ");
        Member member = svc.findMember(mid); // Fail fast on a bad ID.

        System.out.print(svc.booksTable());
        List<String> ids = in.readBookIds("Book IDs (e.g. B001,B002): ", false);
        LocalDate date = in.readDate("Issue date (dd-MM-yyyy, Enter = today): ", true);
        Loan loan = svc.issueBooks(member.getMemberId(), ids, date);
        System.out.println(loan.generateReceipt());
        System.out.println("Updated availability -> " + svc.issuableAvailable() + " of "
                + svc.issuableTotal() + " issuable copies on the shelf");
    }

    private static void returnBook(LibraryService svc, InputHelper in) throws LibraryException {
        System.out.println("--- Return Book ---");
        if (!svc.hasActiveLoans()) {
            System.out.println("[INFO] There are no books currently on loan.");
            return;
        }

        System.out.println("Books currently on loan:");
        System.out.print(svc.activeLoansTable());
        String lid = in.readText("Loan ID : ");
        Loan loan = svc.findLoan(lid); // Fail fast on a bad ID.
        if (loan.isClosed()) {
            throw new InvalidInputException("Loan " + loan.getLoanId() + " is already closed.");
        }

        List<String> ids = in.readBookIds("Book IDs to return (e.g. B001 or ALL): ", true);
        LocalDate date = in.readDate("Return date (dd-MM-yyyy, Enter = today): ", true);
        List<Fine> fines = svc.returnBooks(loan.getLoanId(), ids, date);

        double total = 0;
        for (Fine f : fines) {
            System.out.println(f.generateReceipt());
            total += f.getAmount();
        }
        System.out.println("Total fine payable : " + DateUtil.money(total));
        System.out.println("Updated availability -> " + svc.issuableAvailable() + " of "
                + svc.issuableTotal() + " issuable copies on the shelf");
    }

    private static void displayBooks(LibraryService svc) {
        System.out.println("--- Books & Availability ---");
        System.out.print(svc.booksTable());
        if (svc.hasBooks()) {
            System.out.println("Shelf total : " + svc.issuableAvailable() + " of " + svc.issuableTotal()
                    + " issuable copies available");
        }
    }
}
