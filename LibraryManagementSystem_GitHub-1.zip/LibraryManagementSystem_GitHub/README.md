# Library Management System (Java)

A menu-driven console-based Library Management System.

## Included source files
- `src/main/LibraryApp.java` — console entry point and menu.
- `src/service/LibraryService.java` — core library business logic.

## Important
These two files depend on additional classes that were referenced in the code you supplied. Add the remaining project classes before compiling:
- `exception/`: `InvalidInputException`, `LibraryException`, `BookUnavailableException`, `BorrowLimitExceededException`, `ItemNotFoundException`, `MemberBlockedException`, `ReturnNotAllowedException`
- `model/`: `Author`, `Book`, `FacultyMember`, `Fine`, `Loan`, `LoanItem`, `Magazine`, `Member`, `ReferenceBook`
- `util/`: `DateUtil`, `InputHelper`
- `service/FinePolicy.java` (or update the import/package if your `FinePolicy` is in another package)

## Suggested GitHub repository layout
```text
LibraryManagementSystem/
├── README.md
└── src/
    ├── main/
    │   └── LibraryApp.java
    └── service/
        └── LibraryService.java
```

Keep each Java class in a separate file matching its package declaration. The source files in this archive have been formatted for readability; they have not been compiled because the supporting classes were not included in the supplied code.
